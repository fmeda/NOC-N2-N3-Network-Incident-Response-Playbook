#!/usr/bin/env bash
# Offline analysis only; never starts a live capture.
set -euo pipefail
if [[ $# -ne 2 ]]; then echo 'Usage: pcap_triage.sh capture.pcapng output_directory' >&2; exit 2; fi
pcap="$1"; out="$2"
[[ -f "$pcap" ]] || { echo 'PCAP not found' >&2; exit 1; }
command -v tshark >/dev/null || { echo 'Install tshark' >&2; exit 1; }
mkdir -p "$out"; chmod 700 "$out"
for kind in retransmission duplicate_ack zero_window reset; do
  case "$kind" in
    reset) filter='tcp.flags.reset == 1' ;;
    *) filter="tcp.analysis.$kind" ;;
  esac
  tshark -r "$pcap" -Y "$filter" -T fields -e frame.number -e frame.time_relative -e ip.src -e ip.dst -e tcp.stream > "$out/$kind.tsv"
done
printf 'Offline PCAP triage complete. Outputs may contain sensitive metadata.\n'
