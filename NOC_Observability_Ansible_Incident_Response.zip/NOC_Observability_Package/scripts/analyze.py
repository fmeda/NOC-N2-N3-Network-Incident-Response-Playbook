#!/usr/bin/env python3
"""Analyze Linux ping output; read-only, no configuration changes."""
import csv
import json
import pathlib
import re
import sys
from datetime import datetime, timezone


def main():
    if len(sys.argv) != 3:
        raise SystemExit('Usage: analyze.py icmp_raw.json output_directory')
    data = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8'))
    output = pathlib.Path(sys.argv[2]); output.mkdir(parents=True, exist_ok=True)
    rows = []
    for item in data:
        text = item.get('stdout', '') + '\n' + item.get('stderr', '')
        loss = re.search(r'([\d.]+)% packet loss', text)
        rtt = re.search(r'(?:rtt|round-trip) min/avg/max/(?:mdev|stddev) = [\d.]+/([\d.]+)/', text)
        loss_pct = float(loss.group(1)) if loss else None
        latency_ms = float(rtt.group(1)) if rtt else None
        status = ('UNKNOWN' if loss_pct is None else
                  'CRITICAL' if loss_pct > 5 else
                  'WARNING' if latency_ms is not None and latency_ms > 100 else 'OK')
        rows.append({'timestamp_utc': datetime.now(timezone.utc).isoformat(),
                     'target': item.get('item', {}).get('name', 'unknown'),
                     'address': item.get('item', {}).get('address', ''),
                     'packet_loss_pct': loss_pct, 'avg_rtt_ms': latency_ms,
                     'status': status, 'return_code': item.get('rc')})
    with (output / 'summary.csv').open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]) if rows else
            ['timestamp_utc', 'target', 'address', 'packet_loss_pct', 'avg_rtt_ms', 'status', 'return_code'])
        writer.writeheader(); writer.writerows(rows)
    (output / 'summary.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    for row in rows:
        print(f"{row['target']}: {row['status']} loss={row['packet_loss_pct']}% rtt={row['avg_rtt_ms']}ms")

if __name__ == '__main__':
    main()
