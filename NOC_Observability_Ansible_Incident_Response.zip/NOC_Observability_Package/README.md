# NOC Observability Automation — Ansible + Zabbix + Grafana + Wireshark

## Requirements
- Linux control node with `ansible-core` (2.15+ recommended), Python 3, `iputils-ping`.
- Optional: `tshark` for offline PCAP triage.
- Network reachability to authorized monitoring targets.

## Start
1. Edit `inventory/targets.yml` with your authorized targets. Reserved TEST-NET addresses are placeholders and will not represent real production hosts.
2. From the package root run:
   `ansible-playbook -i inventory/targets.yml playbooks/diagnostics.yml`
3. Review `reports/summary.csv`, `reports/summary.json` and `reports/icmp_raw.json`.
4. For an existing capture: `bash scripts/pcap_triage.sh /path/to/capture.pcapng reports/pcap`.

## Scope and limitations
- The executable playbook implements ICMP packet-loss and average RTT measurement. It does NOT directly install Zabbix triggers, query Grafana, collect SNMP counters, calculate jitter, or perform live packet capture.
- The remaining 8 alarm workflows are documented in the incident-response paper for integration with your existing monitoring stack.
- This is not an automatically self-healing tool. All network changes require approved change control.
- ICMP failures may be due to ACLs, ICMP rate limiting, or host policies; corroborate before declaring outage.
- Thresholds are examples, not production SLAs. Averages and packet-loss measurements from 5 probes are noisy; tune sample counts and windows.
- Offline PCAP exports may contain IPs and other sensitive metadata; apply least privilege and retention policy.
- No credentials or API tokens are included.
