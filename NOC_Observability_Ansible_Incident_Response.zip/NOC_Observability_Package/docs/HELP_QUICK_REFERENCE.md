# NOC N2/N3 — Help rápido

| Arquivo | Para que serve | Como usar |
|---|---|---|
| inventory/targets.yml | Define os destinos e quantidade de testes | Edite `probe_targets` antes da execução |
| playbooks/diagnostics.yml | Executa ping por alvo e salva evidências | `ansible-playbook -i inventory/targets.yml playbooks/diagnostics.yml` |
| scripts/analyze.py | Extrai perda e RTT de saídas de ping | Chamado automaticamente pelo playbook |
| scripts/pcap_triage.sh | Analisa PCAP existente com tshark | `bash scripts/pcap_triage.sh captura.pcapng reports/pcap` |
| reports/summary.csv | Resultado para planilhas/Grafana (importação externa) | Verificar status, perda e latência |
| docs/Incident_Response_Paper.pdf | Procedimentos para os dez alarmes | Consultar durante incidente |

**Interpretação:** OK = sem perda acima de 5% e RTT médio até 100 ms; WARNING = RTT acima de 100 ms; CRITICAL = perda acima de 5%; UNKNOWN = falha na interpretação. Thresholds ilustrativos. O playbook não altera dispositivos.
