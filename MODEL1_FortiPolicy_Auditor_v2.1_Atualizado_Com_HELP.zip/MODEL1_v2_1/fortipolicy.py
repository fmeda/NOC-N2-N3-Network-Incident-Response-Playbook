#!/usr/bin/env python3
"""MODEL1 2.1 — conservative, read-only FortiOS configuration auditor."""
import argparse
import csv
import datetime as dt
import html
import ipaddress
import json
import pathlib
import re
import shlex
import urllib.parse
import urllib.request
from collections import defaultdict

FIELDS = ('srcintf','dstintf','srcaddr','dstaddr','service','schedule','action','nat','status','utm-status','ips-sensor','av-profile','webfilter-profile','application-list','ssl-ssh-profile','logtraffic','comments','poolname','ippool','groups','users','internet-service','internet-service-id','srcaddr-negate','dstaddr-negate','service-negate')
DEFAULTS = {'action':'deny','status':'enable','schedule':'always','nat':'disable','utm-status':'disable'}
SEVERITIES = ('informational','low','medium','high','critical')
CVE_RE = re.compile(r'^CVE-\d{4}-\d{4,}$',re.I)


def tokenize(line):
    try:
        return shlex.split(line, comments=False, posix=True)
    except ValueError:
        return None


def parse(text):
    """Parse config/edit/next/end stack, preserving VDOM and unset, no eval."""
    root={'kind':'root','name':'root','children':[],'settings':{},'unsets':[],'line':0}
    stack=[root]; warnings=[]
    for lineno, raw in enumerate(text.splitlines(),1):
        s=raw.strip()
        if not s or s.startswith('#'): continue
        words=tokenize(s)
        if not words:
            warnings.append(f'Line {lineno}: malformed quotation; skipped'); continue
        cmd=words[0]
        if cmd in ('config','edit'):
            if len(words)<2:
                warnings.append(f'Line {lineno}: incomplete {cmd}');continue
            node={'kind':cmd,'name':' '.join(words[1:]),'children':[],'settings':{},'unsets':[],'line':lineno}
            stack[-1]['children'].append(node);stack.append(node)
        elif cmd in ('next','end'):
            wanted='edit' if cmd=='next' else 'config'
            if len(stack)>1 and stack[-1]['kind']==wanted: stack.pop()
            else: warnings.append(f'Line {lineno}: unmatched {cmd}; parser context retained')
        elif cmd in ('set','append') and len(words)>=3:
            k=words[1];v=words[2:]
            if cmd=='append':stack[-1]['settings'].setdefault(k,[]).extend(v)
            else:stack[-1]['settings'][k]=v
            if k in stack[-1]['unsets']:stack[-1]['unsets'].remove(k)
        elif cmd=='unset' and len(words)==2:
            stack[-1]['settings'].pop(words[1],None);stack[-1]['unsets'].append(words[1])
        elif cmd in ('set','unset','append'):
            warnings.append(f'Line {lineno}: malformed {cmd}')
    if len(stack)>1: warnings.append('Incomplete configuration: unclosed config/edit blocks')
    return root,warnings


def walk(node,path=(),vdom='root'):
    for child in node['children']:
        newpath=path+(child['name'],) if child['kind']=='config' else path
        newvdom=vdom
        if child['kind']=='edit' and path==('vdom',):newvdom=child['name']
        yield child,newpath,newvdom
        yield from walk(child,newpath,newvdom)


def effective(node,key,default=None):
    if key in node['settings']:return node['settings'][key]
    if default is None: default=DEFAULTS.get(key)
    if isinstance(default,(list,tuple)): return list(default)
    return [default] if default is not None else None


def val(node,key,default=None):
    x=effective(node,key,default)
    return ' '.join(x) if x is not None else ''


def extract(root):
    policies=[];objects=defaultdict(dict)
    for node,path,vdom in walk(root):
        if node['kind']!='edit':continue
        if path and path[-1]=='firewall policy':
            policies.append({'id':node['name'],'vdom':vdom,'node':node,'line':node['line'],'order':len([p for p in policies if p['vdom']==vdom])+1})
        elif path and path[-1] in ('firewall address','firewall addrgrp','firewall service custom','firewall service group','firewall vip'):
            objects[(vdom,path[-1])][node['name']]=node
    return policies,objects


def network_object(name,vdom,objects,seen=None):
    seen=seen or set()
    if name=='all':return None
    if name in seen:return ('unknown','cyclic address group')
    a=objects.get((vdom,'firewall address'),{}).get(name)
    if a:
        if val(a,'type','ipmask')!='ipmask':return ('unknown','non-ipmask address object')
        subnet=effective(a,'subnet')
        if subnet:
            try:
                if len(subnet)==2:return {ipaddress.ip_network(subnet[0]+'/'+subnet[1],strict=False)}
                return {ipaddress.ip_network(subnet[0],strict=False)}
            except ValueError:return ('unknown','invalid subnet')
        return ('unknown','address object lacks subnet')
    grp=objects.get((vdom,'firewall addrgrp'),{}).get(name)
    if grp:
        result=set()
        for member in effective(grp,'member',[]) or []:
            x=network_object(member,vdom,objects,seen|{name})
            if x is None:return None
            if isinstance(x,tuple):return x
            result.update(x)
        if val(grp,'exclude')=='enable':return ('unknown','excluded address group')
        return result
    return ('unknown',f'unresolved address: {name}')


def address_coverage(names,vdom,objects):
    if not names:return ('unknown','missing address field')
    if 'all' in names:return None
    out=set()
    for name in names:
        x=network_object(name,vdom,objects)
        if x is None:return None
        if isinstance(x,tuple):return x
        out.update(x)
    return out


def service_coverage(names,vdom,objects,seen=None):
    if not names:return ('unknown','missing service field')
    if 'ALL' in names:return None
    seen=seen or set();out=set()
    for name in names:
        if name in seen:return ('unknown','cyclic service group')
        if name in ('HTTP','HTTPS','DNS','SSH','PING'):
            out.update({'HTTP':{('tcp',80,80)},'HTTPS':{('tcp',443,443)},'DNS':{('tcp',53,53),('udp',53,53)},'SSH':{('tcp',22,22)},'PING':{('icmp',0,0)}}[name]);continue
        group=objects.get((vdom,'firewall service group'),{}).get(name)
        if group:
            x=service_coverage(effective(group,'member',[]) or [],vdom,objects,seen|{name})
            if x is None:return None
            if isinstance(x,tuple):return x
            out.update(x);continue
        item=objects.get((vdom,'firewall service custom'),{}).get(name)
        if not item:return ('unknown',f'unresolved service: {name}')
        if val(item,'protocol') in ('ICMP','ICMP6'):
            out.add(('icmp',0,0));continue
        if val(item,'protocol') not in ('','TCP/UDP/SCTP'):
            return ('unknown','nonstandard service protocol')
        ports=[]
        for proto,key in (('tcp','tcp-portrange'),('udp','udp-portrange'),('sctp','sctp-portrange')):
            for spec in effective(item,key,[]) or []:
                dst=spec.split(':')[0]
                try:
                    parts=dst.split('-');a=int(parts[0]);b=int(parts[-1]);assert 1<=a<=b<=65535
                except (ValueError,AssertionError):return ('unknown','invalid port range')
                ports.append((proto,a,b))
        if not ports:return ('unknown','custom service without supported port ranges')
        out.update(ports)
    return out


def covers(a,b,kind):
    if a is None:return True
    if b is None or isinstance(a,tuple) or isinstance(b,tuple):return False
    if kind=='address':return all(any(x.version==y.version and y.subnet_of(x) for x in a) for y in b)
    return all(any(x[0]==y[0] and x[1]<=y[1] and x[2]>=y[2] for x in a) for y in b)


def semantic_key(p):
    n=p['node']
    return tuple((key,tuple(effective(n,key,[]) or [])) for key in sorted(set(n['settings'])|set(FIELDS)))


def finding(p,code,severity,evidence,recommendation,confidence='high',category='policy'):
    return {'vdom':p['vdom'],'policy_id':p['id'],'policy_name':val(p['node'],'name'),'code':code,'severity':severity,'evidence':evidence,'recommendation':recommendation,'confidence':confidence,'category':category}


def analyze(text):
    root,warnings=parse(text);policies,objects=extract(root);findings=[]
    if not policies:warnings.append('No IPv4 firewall policies found; input may be incomplete or unsupported')
    by_vdom=defaultdict(list)
    for p in policies:by_vdom[p['vdom']].append(p)
    for vdom,group in by_vdom.items():
        prior=[];seen={}
        for p in group:
            n=p['node'];status=val(n,'status');action=val(n,'action')
            if status=='disable':continue
            if action!='accept':
                if action not in ('deny','ipsec'):warnings.append(f'VDOM {vdom} policy {p["id"]}: unsupported action {action}')
                prior.append(p);continue
            src=effective(n,'srcaddr',[]) or [];dst=effective(n,'dstaddr',[]) or [];svc=effective(n,'service',[]) or []
            if 'all' in src:findings.append(finding(p,'ANY_SOURCE','informational','srcaddr contains all','Review source scope in interface and business context.','high'))
            if 'all' in dst:findings.append(finding(p,'ANY_DESTINATION','informational','dstaddr contains all','Review destination scope and routing.','high'))
            if 'ALL' in svc:findings.append(finding(p,'ANY_SERVICE','medium','service contains ALL','Review least-privilege services and exception approval.','high'))
            if 'all' in src and 'all' in dst and 'ALL' in svc:
                findings.append(finding(p,'BROAD_ACCESS_REVIEW','medium','Broad rule; external exposure not established','Confirm source/destination interfaces, zones, routing and business justification.','medium'))
            if val(n,'logtraffic')=='disable':findings.append(finding(p,'LOGGING_DISABLED','low','logtraffic explicitly disable','Check logging policy and compensating telemetry.'))
            elif 'logtraffic' not in n['settings']:
                findings.append(finding(p,'LOGGING_DEFAULT_UNVERIFIED','informational','logtraffic absent or unset; effective default is version dependent','Confirm effective FortiOS version-specific logging setting.','low'))
            key=semantic_key(p)
            if key in seen:findings.append(finding(p,'EXACT_DUPLICATE_CANDIDATE','medium',f'All parsed settings match policy {seen[key]} (order may affect semantics)','Review order and any external policy dependencies.','medium'))
            else:seen[key]=p['id']
            # Strict, conservative full shadow: same interface and schedule, known positive address/service coverage,
            # no identity/negation/internet-service constraints, no unsupported match dimensions.
            match_fields=('srcintf','dstintf','schedule')
            blockers=('srcaddr-negate','dstaddr-negate','service-negate','internet-service','groups','users','fsso-groups','identity-based-route','ztna-status')
            if any(val(n,k) in ('enable','1') if 'negate' in k else bool(val(n,k)) for k in blockers):
                prior.append(p);continue
            for earlier in prior:
                en=earlier['node']
                if val(en,'action') not in ('accept','deny'):continue
                if any(val(en,k) in ('enable','1') if 'negate' in k else bool(val(en,k)) for k in blockers):continue
                if any(tuple(effective(n,k,[]) or [])!=tuple(effective(en,k,[]) or []) for k in match_fields):continue
                if not all(effective(n,k) and effective(en,k) for k in ('srcintf','dstintf','srcaddr','dstaddr','service')):continue
                if not all(covers(address_coverage(effective(en,k),vdom,objects),address_coverage(effective(n,k),vdom,objects),'address') for k in ('srcaddr','dstaddr')):continue
                if not covers(service_coverage(effective(en,'service'),vdom,objects),service_coverage(effective(n,'service'),vdom,objects),'service'):continue
                # shadowing not established if schedule is a named object with unknown semantics? equality is sufficient.
                findings.append(finding(p,'FULL_SHADOW_CANDIDATE','medium',f'Preceding policy {earlier["id"]} covers parsed address/service match fields; verify additional FortiOS conditions','Validate policy order and match with FortiGate policy lookup before removal.','medium'))
                break
            prior.append(p)
    if not any('config system global' in text for _ in [0]):
        warnings.append('FortiOS release/build not independently verified; default values beyond documented stable fields require device validation')
    warnings.append('Read-only static analysis. Routing, policy routes, dynamic objects, user identity, runtime exposure, and active exploitation are not verified.')
    serialized=[{'id':p['id'],'vdom':p['vdom'],'order':p['order'],'line':p['line'],'settings':p['node']['settings'],'unsets':p['node']['unsets'],'effective_action':val(p['node'],'action'),'effective_status':val(p['node'],'status')} for p in policies]
    return {'policies':serialized,'findings':findings,'warnings':warnings}


def fetch_json(url,timeout=12):
    req=urllib.request.Request(url,headers={'User-Agent':'MODEL1-FortiPolicy-Auditor/2.1 read-only','Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=timeout) as r:
        if int(r.headers.get('Content-Length','0'))>8_000_000:raise ValueError('Response too large')
        data=r.read(8_000_001)
        if len(data)>8_000_000:raise ValueError('Response too large')
        return json.loads(data)


def intelligence(cves,online=False,firmware=None,fetcher=fetch_json):
    """CVE enrichment, never assert affected firmware from NVD text alone."""
    result=[];kev=None;kev_error=None
    if online and cves:
        try:
            x=fetcher('https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json')
            kev={v['cveID'] for v in x.get('vulnerabilities',[]) if 'cveID' in v}
        except Exception as e:kev_error=f'{type(e).__name__}: {e}'
    for cve in cves:
        if not CVE_RE.fullmatch(cve):raise ValueError('Invalid CVE identifier: '+cve)
        cve=cve.upper()
        item={'cve':cve,'firmware_claim':firmware,'applicability':'insufficient_evidence','cisa_kev':None,'epss':None,'epss_percentile':None,'nvd_published':None,'nvd_description':None,'source_errors':[],'source_status':'offline' if not online else 'partial','verified_at':None}
        if online:
            item['verified_at']=dt.datetime.now(dt.timezone.utc).isoformat()
            if kev is not None:item['cisa_kev']=cve in kev
            else:item['source_errors'].append('CISA KEV unavailable: '+str(kev_error))
            try:
                x=fetcher('https://api.first.org/data/v1/epss?'+urllib.parse.urlencode({'cve':cve}))
                if x.get('data'):
                    item['epss']=x['data'][0].get('epss');item['epss_percentile']=x['data'][0].get('percentile')
            except Exception as e:item['source_errors'].append('EPSS unavailable: '+str(e))
            try:
                x=fetcher('https://services.nvd.nist.gov/rest/json/cves/2.0?'+urllib.parse.urlencode({'cveId':cve}))
                for entry in x.get('vulnerabilities',[]):
                    record=entry.get('cve',{})
                    if record.get('id','').upper()!=cve:continue
                    item['nvd_published']=record.get('published')
                    item['nvd_description']=next((d.get('value') for d in record.get('descriptions',[]) if d.get('lang')=='en'),None)
                    item['nvd_url']='https://nvd.nist.gov/vuln/detail/'+cve
                    break
            except Exception as e:item['source_errors'].append('NVD unavailable: '+str(e))
            item['source_status']='partial' if item['source_errors'] else 'queried'
        result.append(item)
    return result


def write_reports(result,outdir):
    path=pathlib.Path(outdir);path.mkdir(parents=True,exist_ok=True)
    (path/'audit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    fields=['vdom','policy_id','policy_name','code','severity','evidence','recommendation','confidence','category']
    with (path/'findings.csv').open('w',newline='',encoding='utf-8') as fh:
        w=csv.DictWriter(fh,fieldnames=fields);w.writeheader();w.writerows(result['findings'])
    def td(x):return '<td>'+html.escape(str(x))+'</td>'
    rows=''.join('<tr>'+''.join(td(f.get(k,'')) for k in fields)+'</tr>' for f in result['findings'])
    cvfields=['cve','firmware_claim','applicability','cisa_kev','epss','source_status','verified_at']
    cvrows=''.join('<tr>'+''.join(td(c.get(k,'')) for k in cvfields)+'</tr>' for c in result.get('cve_intelligence',[]))
    warnings=''.join('<li>'+html.escape(w)+'</li>' for w in result['warnings'])
    css='body{font:15px system-ui;background:#101827;color:#e6edf6;margin:32px}h1,h2{color:#75b8ff}table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:9px;border:1px solid #42516a;text-align:left;vertical-align:top}th{background:#263953}.panel{background:#1a293e;padding:18px;border-radius:12px;margin:18px 0}'
    page='<!doctype html><html lang="en"><head><meta charset="utf-8"><title>MODEL1 2.1 Audit</title><style>'+css+'</style></head><body><h1>MODEL1 FortiPolicy Auditor 2.1</h1><div class="panel">Generated: '+html.escape(result['generated_at'])+' | Policies: '+str(len(result['policies']))+' | Findings: '+str(len(result['findings']))+'</div><h2>Limitations</h2><ul>'+warnings+'</ul><h2>Findings</h2><table><tr>'+''.join('<th>'+html.escape(k)+'</th>' for k in fields)+'</tr>'+rows+'</table><h2>CVE intelligence (applicability not established)</h2><table><tr>'+''.join('<th>'+html.escape(k)+'</th>' for k in cvfields)+'</tr>'+cvrows+'</table></body></html>'
    (path/'report.html').write_text(page,encoding='utf-8')


def main(argv=None):
    ap=argparse.ArgumentParser(description='MODEL1 2.1 — read-only FortiOS policy static audit')
    ap.add_argument('--input',required=True);ap.add_argument('--output',default='reports');ap.add_argument('--policy');ap.add_argument('--vdom');ap.add_argument('--cve',action='append',default=[]);ap.add_argument('--firmware',help='Informational only; NOT verified for CVE applicability');ap.add_argument('--online',action='store_true')
    args=ap.parse_args(argv)
    try:
        source=pathlib.Path(args.input).read_text(encoding='utf-8',errors='replace')
        result=analyze(source)
        if args.policy:result['policies']=[p for p in result['policies'] if p['id']==args.policy]
        if args.vdom:result['policies']=[p for p in result['policies'] if p['vdom']==args.vdom]
        selected={(p['vdom'],p['id']) for p in result['policies']}
        result['findings']=[f for f in result['findings'] if (f['vdom'],f['policy_id']) in selected]
        if not selected:result['warnings'].append('Requested policy or VDOM not found')
        result['cve_intelligence']=intelligence(args.cve,args.online,args.firmware)
        result['warnings'].append('CVE lookups do not establish firmware applicability; Fortinet PSIRT version-range validation is not implemented.')
        result['generated_at']=dt.datetime.now(dt.timezone.utc).isoformat()
        write_reports(result,args.output)
        print(f'MODEL1 2.1: {len(result["policies"])} policies; {len(result["findings"])} findings; {args.output}')
        return 0
    except (OSError,ValueError) as e:
        ap.error(str(e))

if __name__=='__main__':raise SystemExit(main())
