import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from fortipolicy import analyze,parse,extract,network_object,service_coverage,intelligence,write_reports
from tempfile import TemporaryDirectory

BASE='''config firewall policy
edit 1
set srcintf "lan"
set dstintf "wan"
set srcaddr "all"
set dstaddr "all"
set service "ALL"
set action accept
next
end
'''
def policy(pid,extra='',src='all',dst='all',service='ALL',action='accept'):
 return f'''edit {pid}\nset srcintf "lan"\nset dstintf "wan"\nset srcaddr "{src}"\nset dstaddr "{dst}"\nset service "{service}"\nset action {action}\n{extra}\nnext\n'''
def config(*items):return 'config firewall policy\n'+''.join(items)+'end\n'
class Regression(unittest.TestCase):
 def codes(self,text):return [f['code'] for f in analyze(text)['findings']]
 def test_two_vdoms(self):
  s='config vdom\nedit A\n'+config(policy(1))+'next\nedit B\n'+config(policy(1))+'next\nend\n'
  self.assertEqual({p['vdom'] for p in analyze(s)['policies']},{'A','B'})
 def test_unset_action_defaults_deny(self):
  s=config(policy(1,'unset action'))
  r=analyze(s);self.assertEqual(r['policies'][0]['effective_action'],'deny');self.assertNotIn('ANY_SOURCE',[f['code'] for f in r['findings']])
 def test_missing_action_defaults_deny(self):
  self.assertEqual(analyze(config(policy(1).replace('set action accept\n','')))['policies'][0]['effective_action'],'deny')
 def test_disable_skipped(self):self.assertEqual(analyze(config(policy(1,'set status disable')))['findings'],[])
 def test_different_utm_not_exact_duplicate(self):
  s=config(policy(1,'set utm-status enable\nset ips-sensor "strict"'),policy(2,'set utm-status disable'))
  self.assertNotIn('EXACT_DUPLICATE_CANDIDATE',self.codes(s))
 def test_exact_duplicate(self):self.assertIn('EXACT_DUPLICATE_CANDIDATE',self.codes(config(policy(1),policy(2))))
 def test_different_vdom_not_duplicate(self):
  s='config vdom\nedit A\n'+config(policy(1))+'next\nedit B\n'+config(policy(2))+'next\nend\n'
  self.assertNotIn('EXACT_DUPLICATE_CANDIDATE',self.codes(s))
 def test_service_all_contextual(self):
  f=next(x for x in analyze(BASE)['findings'] if x['code']=='ANY_SERVICE')
  self.assertEqual(f['severity'],'medium')
 def test_missing_log_unknown(self):self.assertIn('LOGGING_DEFAULT_UNVERIFIED',self.codes(BASE))
 def test_explicit_disabled_log(self):self.assertIn('LOGGING_DISABLED',self.codes(config(policy(1,'set logtraffic disable'))))
 def test_nested_address_group(self):
  s='''config firewall address
edit "subnet"
set subnet 10.0.0.0 255.255.255.0
next
end
config firewall addrgrp
edit "group"
set member "subnet"
next
end
'''
  root,_=parse(s);_,objects=extract(root)
  self.assertEqual({str(n) for n in network_object('group','root',objects)},{'10.0.0.0/24'})
 def test_nested_service_group(self):
  s='''config firewall service custom
edit "webport"
set tcp-portrange 8443
next
end
config firewall service group
edit "webgroup"
set member "webport"
next
end
'''
  root,_=parse(s);_,objects=extract(root)
  self.assertEqual(service_coverage(['webgroup'],'root',objects),{('tcp',8443,8443)})
 def test_shadow_known_coverage(self):
  s='''config firewall address
edit "subnet"
set subnet 10.0.0.0 255.255.255.0
next
end
'''+config(policy(1),policy(2,src='subnet',service='HTTPS'))
  self.assertIn('FULL_SHADOW_CANDIDATE',self.codes(s))
 def test_no_shadow_unknown_address(self):
  self.assertNotIn('FULL_SHADOW_CANDIDATE',self.codes(config(policy(1,src='unknown'),policy(2,src='all'))))
 def test_no_shadow_other_interface(self):
  s=config(policy(1),policy(2).replace('"lan"','"dmz"'))
  self.assertNotIn('FULL_SHADOW_CANDIDATE',self.codes(s))
 def test_no_shadow_negated(self):self.assertNotIn('FULL_SHADOW_CANDIDATE',self.codes(config(policy(1,'set srcaddr-negate enable'),policy(2))))
 def test_cve_offline_unknown(self):
  r=intelligence(['CVE-2024-21762'],False,'7.2.8')[0]
  self.assertEqual(r['applicability'],'insufficient_evidence');self.assertIsNone(r['cisa_kev'])
 def test_cve_mocked_feeds(self):
  def mock(url):
   if 'known_exploited' in url:return {'vulnerabilities':[{'cveID':'CVE-2024-21762'}]}
   if 'epss' in url:return {'data':[{'epss':'0.7','percentile':'0.9'}]}
   return {'vulnerabilities':[{'cve':{'id':'CVE-2024-21762','published':'2024-01-01','descriptions':[{'lang':'en','value':'Example'}]}}]}
  r=intelligence(['CVE-2024-21762'],True,'7.2.8',mock)[0]
  self.assertTrue(r['cisa_kev']);self.assertEqual(r['epss'],'0.7');self.assertEqual(r['applicability'],'insufficient_evidence')
 def test_cve_feed_failure_not_false_negative(self):
  def broken(_):raise OSError('offline')
  r=intelligence(['CVE-2024-21762'],True,fetcher=broken)[0]
  self.assertIsNone(r['cisa_kev']);self.assertEqual(len(r['source_errors']),3)
 def test_report_html_escaping(self):
  r=analyze(config(policy(1,'set name "<script>alert(1)</script>"')));r['generated_at']='test';r['cve_intelligence']=[]
  with TemporaryDirectory() as d:
   write_reports(r,d)
   self.assertNotIn('<script>',(Path(d)/'report.html').read_text())
   self.assertTrue((Path(d)/'findings.csv').exists())
 def test_nested_config_no_context_leak(self):
  s='config firewall policy\nedit 1\nconfig identity-based-policy\nedit 2\nset action accept\nnext\nend\nset action deny\nnext\nend'
  self.assertEqual(analyze(s)['policies'][0]['effective_action'],'deny')
if __name__=='__main__':unittest.main()
