# MODEL1 FortiPolicy Auditor v2.1 — regression hardening

**Read-only offline FortiOS policy auditing**, optional online enrichment for explicitly supplied CVE IDs. Python 3.10+, standard library only. This is an engineering prototype, **not production-certified**.

## Run

```bash
python fortipolicy.py --input samples/legacy_sample.conf --output reports
python fortipolicy.py --input samples/legacy_sample.conf --policy 100 --output reports/single
python fortipolicy.py --input samples/multi_vdom.conf --vdom BRANCH --output reports/branch
python fortipolicy.py --input samples/legacy_sample.conf --cve CVE-2024-21762 --online --firmware 7.2.8 --output reports/cve
python -m unittest discover -s tests -v
```

Output: `audit.json`, `findings.csv`, `report.html`. `--firmware` is a **user-supplied label**, not proof of CVE applicability. Online CVE checks require Internet and may be rate-limited.

## Changes compared with original MVP

- Stack-based `config` / `edit` parser, tracking VDOM and `unset`.
- `action=deny` and `status=enable` effective defaults; version-specific defaults not asserted for logging.
- Exact-configuration duplicate candidate compares all parsed `set` fields, including UTM settings, per VDOM.
- Conservative full shadow **candidate** when earlier policy covers known IPv4 address and TCP/UDP service ranges, same interface and schedule; unsupported match dimensions inhibit assertions.
- Recursive resolution of `firewall address`, `firewall addrgrp`, `firewall service custom`, `firewall service group`, with unknown/cycle handling.
- Context-sensitive severity for `all` rather than asserting Internet exposure.
- CVE feed errors are explicit and KEV unavailable remains `null` rather than `false`. CVE applicability stays `insufficient_evidence`.
- HTML escaping of user-supplied policy names; no credentials or device access needed.

## Known limitations (important)

- Only `firewall policy` (IPv4) is analyzed. Other policy types, IPv6, dynamic objects, FQDN, geographic objects, VIPs, Internet Service Database, central NAT, routes, policy routes, user identities and complex schedules are **not** fully modeled.
- Some FortiOS service built-in names and features vary by version; unsupported objects produce unknown rather than an assumed match. Port-range parsing is conservative and not a complete FortiOS service grammar.
- Shadowing is a **candidate**, not proof of reachability or safe rule deletion. Match conditions outside the supported subset, including nested identity rules and features not explicitly modeled, may invalidate a candidate. Validate on the actual FortiGate before remediation.
- Policy-level security profiles may differ in semantics even when two rules match the same packets. Duplicate detection is not a deletion recommendation.
- `unset` is interpreted as absent and defaulted only for a small stable subset. FortiOS version-specific defaults must be verified with vendor documentation and device state.
- No automated PSIRT version range correlation. NVD/KEV/EPSS enrichment does not prove a device vulnerable; **never treat a CVE as confirmed affected** from this tool.
- No REST API, PDF, UI, Zabbix, Wazuh or live FortiAnalyzer integration in this release.
- Audit JSON contains original rule settings and may contain confidential IPs, policy comments and other values; protect reports appropriately.

## Safety

The tool reads local configuration files and optionally performs HTTPS GET requests to NVD, CISA KEV and FIRST EPSS. It never connects to a FortiGate or changes a policy. Analyze only configurations you are authorized to inspect.
