#!/usr/bin/env python3
"""MODEL1 FortiPolicy Auditor - read-only offline FortiOS policy audit and optional CVE enrichment."""
import argparse, csv, datetime as dt, html, ipaddress, json, pathlib, re, urllib.request, urllib.error
from collections import Counter

def blocks(text, name):
    match=re.search(r'^config '+re.escape(name)+r'\s*$',text,re.M)
    if not match:return []
    lines=text[match.end():].splitlines(); depth=1; current=None; items=[]
    for line in lines:
        s=line.strip()
        if s.startswith('config '): depth+=1
        elif s=='end':
            depth-=1
            if depth==0:break
        if depth!=1:continue
        m=re.match(r'edit\s+(.+)',s)
        if m: current={'id':m.group(1).strip('"')};continue
        if s=='next' and current is not None:items.append(current);current=None;continue
        m=re.match(r'set\s+(\S+)\s+(.+)',s)
        if m and current is not None:
            current[m.group(1)]=re.findall(r'"([^"]*)"|(\S+)',m.group(2))
            current[m.group(1)]=[a or b for a,b in current[m.group(1)]]
    return items

def value(p,k,default=''):
    x=p.get(k,[]);return ' '.join(x) if isinstance(x,list) else str(x or default)

def add(findings,p,code,severity,detail,fix):
    findings.append({'policy_id':p['id'],'policy_name':value(p,'name'),'code':code,'severity':severity,'evidence':detail,'recommendation':fix,'confidence':'high' if code!='MISSING_CONTEXT' else 'low'})

def analyze(text):
    policies=blocks(text,'firewall policy'); findings=[]
    if not policies: return {'policies':[],'findings':[],'warnings':['No IPv4 firewall policy block found; unsupported or incomplete configuration.']}
    for p in policies:
        if value(p,'status')=='disable':continue
        if value(p,'action')!='accept':continue
        src=value(p,'srcaddr');dst=value(p,'dstaddr');svc=value(p,'service')
        if src=='all':add(findings,p,'ANY_SOURCE','medium','srcaddr all','Restrict source addresses to business-required objects.')
        if dst=='all':add(findings,p,'ANY_DESTINATION','medium','dstaddr all','Restrict destinations where possible.')
        if svc=='ALL':add(findings,p,'ANY_SERVICE','high','service ALL','Use explicit required protocols and ports.')
        if value(p,'logtraffic') in ('disable',''):
            add(findings,p,'LOGGING_DISABLED' if value(p,'logtraffic')=='disable' else 'LOGGING_UNSPECIFIED','medium' if value(p,'logtraffic')=='disable' else 'informational','logtraffic '+(value(p,'logtraffic') or '(not specified; default depends on FortiOS)'),'Review traffic logging requirements and actual inherited/default settings.')
        if src=='all' and dst=='all' and svc=='ALL':add(findings,p,'BROAD_ACCESS','high','Any source, any destination, any service','Review least-privilege scope, interfaces, zones and routing before changes.')
    # Conservative duplicate detection only: exact normalized keys, no claims of reachability.
    seen={}
    fields=('srcintf','dstintf','srcaddr','dstaddr','service','schedule','action','nat','status')
    for p in policies:
        if value(p,'status')=='disable':continue
        key=tuple(value(p,k) for k in fields)
        if key in seen:add(findings,p,'POSSIBLE_DUPLICATE','medium',f'Same core fields as policy {seen[key]}; other settings not compared','Review full policy semantics and ordering before consolidation.')
        else:seen[key]=p['id']
    return {'policies':policies,'findings':findings,'warnings':['Offline static review only: routing, object expansion, effective exposure, hit counts, policy shadowing and FortiOS defaults are not verified.']}

def fetch_json(url):
    req=urllib.request.Request(url,headers={'User-Agent':'FortiPolicyAuditor/0.1 (read-only)','Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=15) as r:return json.load(r)

def intelligence(cves,online=False):
    out=[]
    kev={}
    if online:
        try:
            feed=fetch_json('https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json')
            kev={x['cveID']:x for x in feed.get('vulnerabilities',[])}
        except Exception as e:kev={'_error':str(e)}
    for cve in cves:
        entry={'cve':cve,'applicability':'not_assessed','cisa_kev':None,'epss':None,'source_status':'offline'}
        if online:
            entry['source_status']='partial'
            if '_error' not in kev:entry['cisa_kev']=cve in kev
            else:entry['errors']=['CISA KEV unavailable: '+kev['_error']]
            try:
                x=fetch_json('https://api.first.org/data/v1/epss?cve='+cve)
                if x.get('data'):entry['epss']=x['data'][0].get('epss');entry['epss_percentile']=x['data'][0].get('percentile')
            except Exception as e:entry.setdefault('errors',[]).append('EPSS unavailable: '+str(e))
            try:
                x=fetch_json('https://services.nvd.nist.gov/rest/json/cves/2.0?cveId='+cve)
                if x.get('vulnerabilities'):
                    c=x['vulnerabilities'][0]['cve'];entry['nvd_published']=c.get('published');entry['nvd_description']=next((d['value'] for d in c.get('descriptions',[]) if d.get('lang')=='en'),'')
                    entry['nvd_url']='https://nvd.nist.gov/vuln/detail/'+cve
            except Exception as e:entry.setdefault('errors',[]).append('NVD unavailable: '+str(e))
        out.append(entry)
    return out

def write_reports(result,outdir):
    p=pathlib.Path(outdir);p.mkdir(parents=True,exist_ok=True)
    (p/'audit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8')
    fields=['policy_id','policy_name','code','severity','evidence','recommendation','confidence']
    with (p/'findings.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(result['findings'])
    rows=''.join('<tr>'+''.join('<td>'+html.escape(str(x.get(k,'')))+'</td>' for k in fields)+'</tr>' for x in result['findings'])
    warn=''.join('<li>'+html.escape(s)+'</li>' for s in result['warnings'])
    cves=''.join('<tr>'+''.join('<td>'+html.escape(str(x.get(k,'')))+'</td>' for k in ('cve','applicability','cisa_kev','epss','source_status'))+'</tr>' for x in result.get('cve_intelligence',[]))
    page=f'''<!doctype html><html><head><meta charset="utf-8"><title>MODEL1 Security Audit</title><style>body{{font:15px system-ui;background:#101827;color:#e6edf6;margin:32px}}h1,h2{{color:#75b8ff}}table{{border-collapse:collapse;width:100%;font-size:13px}}td,th{{padding:9px;border:1px solid #42516a;text-align:left;vertical-align:top}}th{{background:#263953}}.panel{{background:#1a293e;padding:18px;border-radius:12px;margin:18px 0}}</style></head><body><h1>MODEL1 — FortiPolicy Auditor</h1><div class="panel">Generated: {html.escape(result['generated_at'])} · Policies: {len(result['policies'])} · Findings: {len(result['findings'])}</div><h2>Scope and limitations</h2><ul>{warn}</ul><h2>Policy findings</h2><table><tr>{''.join('<th>'+k+'</th>' for k in fields)}</tr>{rows}</table><h2>CVE intelligence (not asset applicability)</h2><table><tr><th>CVE</th><th>Applicability</th><th>CISA KEV</th><th>EPSS</th><th>Feed status</th></tr>{cves}</table></body></html>'''
    (p/'report.html').write_text(page,encoding='utf8')

def main():
    ap=argparse.ArgumentParser(description='MODEL1 read-only FortiGate policy audit')
    ap.add_argument('--input',required=True,help='FortiOS text configuration')
    ap.add_argument('--output',default='reports')
    ap.add_argument('--policy',help='Restrict analysis to one policy ID')
    ap.add_argument('--cve',action='append',default=[],help='CVE ID for optional lookup (repeatable)')
    ap.add_argument('--online',action='store_true',help='Query NVD, CISA KEV and FIRST EPSS')
    args=ap.parse_args()
    source=pathlib.Path(args.input).read_text(encoding='utf8',errors='replace')
    result=analyze(source)
    if args.policy:
        result['policies']=[x for x in result['policies'] if x['id']==args.policy]
        result['findings']=[x for x in result['findings'] if x['policy_id']==args.policy]
        if not result['policies']:result['warnings'].append('Requested policy not found.')
    result['generated_at']=dt.datetime.now(dt.timezone.utc).isoformat()
    cves=[x.upper() for x in args.cve if re.fullmatch(r'CVE-\d{4}-\d{4,}',x,re.I)]
    result['cve_intelligence']=intelligence(cves,args.online)
    result['warnings'].append('CVE lookup does not establish installed firmware applicability or active exploitation.')
    write_reports(result,args.output)
    print(f"Audited {len(result['policies'])} policies; {len(result['findings'])} findings. Reports in {args.output}")
if __name__=='__main__':main()
